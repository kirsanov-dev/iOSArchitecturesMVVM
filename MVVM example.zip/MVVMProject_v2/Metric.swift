//
//  Metric.swift
//  MVVMProject_v2
//
//  Created by Oleg Kirsanov on 19.09.2021.
//

import UIKit

enum Metric {
    static let parentStackViewSpacing: CGFloat = 30
    static let buttonStackViewSpacing: CGFloat = 15
    
    static let buttonFontSize: CGFloat = 20
    static let buttonHeight: CGFloat = 50
    static let buttonCornerRadius: CGFloat = 7
    static let labelFontSize: CGFloat = 35
    
    static let bottomOffset: CGFloat = -50
    static let topOffset: CGFloat = 15
    static let leftOffset: CGFloat = 15
    static let rightOffset: CGFloat = -15
}
