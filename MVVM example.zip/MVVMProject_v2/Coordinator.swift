//
//  Coordinator.swift
//  MVVMProject_v2
//
//  Created by Oleg Kirsanov on 19.09.2021.
//


import UIKit

enum Event {
    case showButtonTapped
    case dismissPassCode
}

enum Result {
    case correct
    case incorrect
}

protocol Coordinator {
    var navigationController: UINavigationController? { get set }
    func eventOccured(with type: Event)
    func start()
}

protocol Coordinating {
    var coordinator: Coordinator? { get set }
}
