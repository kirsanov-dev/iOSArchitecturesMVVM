//
//  AppCoordinator.swift
//  MVVMProject_v2
//
//  Created by Oleg Kirsanov on 19.09.2021.
//

import UIKit

class AppCoordinator: Coordinator {
    var navigationController: UINavigationController?
    
    let messageVC = MessageViewController()
    let viewModel = ViewModel()
    let passCodeVC = PassCodeViewController()
    
    func eventOccured(with type: Event) {
        switch type {
        case .showButtonTapped:
            passCodeVC.coordinator = self
            navigationController?.present(passCodeVC, animated: true, completion: nil)
            passCodeVC.delegate = viewModel
            viewModel.viewModelDelegate = messageVC
        case .dismissPassCode:
            messageVC.coordinator = self
            navigationController?.dismiss(animated: true, completion: nil)
        }
    }
    
    func start() {
        messageVC.coordinator = self
        navigationController?.setViewControllers([messageVC], animated: false)
    }
    
    
}
