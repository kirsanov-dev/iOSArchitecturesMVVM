//
//  PassCodeViewController.swift
//  MVVMProject_v2
//
//  Created by Oleg Kirsanov on 19.09.2021.
//

import UIKit

protocol PassCodeViewControllerDelegate: AnyObject {
    func didEnterPassCode(_ vc: PassCodeViewController, text: String) -> Bool
}

class PassCodeViewController: UIViewController, Coordinating {
    var coordinator: Coordinator?
    
    weak var delegate: PassCodeViewControllerDelegate?
    
    private lazy var parentStackView: UIStackView = {
        let stackView = UIStackView()
        stackView.axis = .vertical
        stackView.spacing = Metric.parentStackViewSpacing
        stackView.translatesAutoresizingMaskIntoConstraints = false
        return stackView
    }()
    
    private lazy var buttonStackView: UIStackView = {
        let stackView = UIStackView()
        stackView.axis = .vertical
        stackView.spacing = Metric.buttonStackViewSpacing
        stackView.translatesAutoresizingMaskIntoConstraints = false
        return stackView
    }()
    
    private func createHorizontalStackView() -> UIStackView {
        let stackView = UIStackView()
        stackView.axis = .horizontal
        stackView.spacing = Metric.buttonStackViewSpacing
        stackView.distribution = .fillEqually
        
        stackView.translatesAutoresizingMaskIntoConstraints = false
        return stackView
    }
    
    private func createButton(title: String) -> UIButton {
        let button = UIButton()
        button.translatesAutoresizingMaskIntoConstraints = false
        button.setTitle(title, for: .normal)
        button.backgroundColor = .systemGray6
        button.layer.cornerRadius = Metric.buttonCornerRadius
        button.heightAnchor.constraint(equalToConstant: Metric.buttonHeight).isActive = true
        button.clipsToBounds = true
        button.titleLabel?.font = UIFont(name: "Arial", size: Metric.buttonFontSize)
        button.setTitleColor(.systemBlue, for: .normal)
        
        switch title {
        case "Enter":
            button.addTarget(self, action: #selector(enter), for: .touchUpInside)
        case "Clear":
            button.addTarget(self, action: #selector(clear), for: .touchUpInside)
        default:
            button.addTarget(self, action: #selector(numberButtonTapped), for: .touchUpInside)
        }
        
        return button
    }
    
    private lazy var firstStackView = createHorizontalStackView()
    private lazy var buttonNine = createButton(title: "9")
    private lazy var buttonEight = createButton(title: "8")
    private lazy var buttonSeven = createButton(title: "7")
    
    private lazy var secondStackView = createHorizontalStackView()
    private lazy var buttonSix = createButton(title: "6")
    private lazy var buttonFive = createButton(title: "5")
    private lazy var buttonFour = createButton(title: "4")
    
    private lazy var thirdStackView = createHorizontalStackView()
    private lazy var buttonThree = createButton(title: "3")
    private lazy var buttonTwo = createButton(title: "2")
    private lazy var buttonOne = createButton(title: "1")
    
    private lazy var fourthStackView = createHorizontalStackView()
    private lazy var buttonClear = createButton(title: "Clear")
    private lazy var buttonZero = createButton(title: "0")
    private lazy var buttonEnter = createButton(title: "Enter")
    
    private lazy var label: UILabel = {
        let label = UILabel()
        label.textAlignment = .center
        label.font = UIFont(name: "Arial", size: Metric.labelFontSize)
        label.textColor = .systemGray5
        label.text = "Enter the pass code"
        return label
    }()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .white
        title = "Pass Code"
        setupHierarchy()
        setupLayout()
    }
    
    private func setupHierarchy() {
        view.addSubview(parentStackView)
        parentStackView.addArrangedSubview(label)
        parentStackView.addArrangedSubview(buttonStackView)
        
        buttonStackView.addArrangedSubview(firstStackView)
        firstStackView.addArrangedSubview(buttonSeven)
        firstStackView.addArrangedSubview(buttonEight)
        firstStackView.addArrangedSubview(buttonNine)
        
        buttonStackView.addArrangedSubview(secondStackView)
        secondStackView.addArrangedSubview(buttonFour)
        secondStackView.addArrangedSubview(buttonFive)
        secondStackView.addArrangedSubview(buttonSix)
        
        buttonStackView.addArrangedSubview(thirdStackView)
        thirdStackView.addArrangedSubview(buttonOne)
        thirdStackView.addArrangedSubview(buttonTwo)
        thirdStackView.addArrangedSubview(buttonThree)
        
        buttonStackView.addArrangedSubview(fourthStackView)
        fourthStackView.addArrangedSubview(buttonClear)
        fourthStackView.addArrangedSubview(buttonZero)
        fourthStackView.addArrangedSubview(buttonEnter)
    }
    
    private func setupLayout() {
        parentStackView.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: Metric.leftOffset).isActive = true
        parentStackView.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: Metric.rightOffset).isActive = true
        parentStackView.bottomAnchor.constraint(equalTo: view.bottomAnchor, constant: Metric.bottomOffset).isActive = true
    }
    
    @objc func numberButtonTapped(_ sender: UIButton) {
        let count = label.text?.count
        guard let count = count else { return }
        label.textColor = .systemBlue
        if label.text == "Enter the pass code" || label.text == "Incorrect, try again" {
            label.text! = sender.titleLabel!.text!
        }
        if count > 0 && count < 4 {
            label.text! += sender.titleLabel!.text!
        }
    }
    
    @objc func enter() {
        if let correct = delegate?.didEnterPassCode(self, text: label.text!), correct == true {
            clear()
        } else {
            label.textColor = .systemPink
            label.text = "Incorrect, try again"
        }
    }
    
    @objc func clear() {
        label.textColor = .systemGray5
        label.text! = "Enter the pass code"
    }
}
