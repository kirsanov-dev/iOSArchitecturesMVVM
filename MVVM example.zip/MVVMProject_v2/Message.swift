//
//  Message.swift
//  MVVMProject_v2
//
//  Created by Oleg Kirsanov on 19.09.2021.
//

import Foundation

struct Message {
    var text: [String]
    var pass: String
    
    init(text: [String], pass: String) {
        self.text = text
        self.pass = pass
    }
}
