//
//  ViewModel.swift
//  MVVMProject_v2
//
//  Created by Oleg Kirsanov on 19.09.2021.
//

import UIKit

protocol ViewModelDelegate: AnyObject {
    func enteredCorrectPassCode(message: String)
}

class ViewModel {
    
    weak var viewModelDelegate: ViewModelDelegate?
    
    var coordinator: Coordinator?
    
    var message = Message(text:
                            ["No pain, no gain",
                             "It's the final countdown",
                             "Eat, sleep, code",
                             "To be or not to be?",
                             "I drink your milkshake!",
                             "They call it a Royale with cheese",
                             "Nobody's perfect!"
                            ], pass: "1234")
}

extension ViewModel: PassCodeViewControllerDelegate {
    func didEnterPassCode(_ vc: PassCodeViewController, text: String) -> Bool {
        if text == message.pass {
            viewModelDelegate?.enteredCorrectPassCode(message: message.text.randomElement() ?? "")
            return true
        }
        return false
    }
}
