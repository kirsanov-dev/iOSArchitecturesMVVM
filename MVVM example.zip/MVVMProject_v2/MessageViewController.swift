//
//  MessageViewController.swift
//  MVVMProject_v2
//
//  Created by Oleg Kirsanov on 19.09.2021.
//

import UIKit

class MessageViewController: UIViewController, Coordinating {
    
    var viewModel: ViewModel!
    
    var coordinator: Coordinator?
    
    private lazy var messageLabel: UILabel = {
        let label = UILabel()
        label.translatesAutoresizingMaskIntoConstraints = false
        label.font = UIFont(name: "Arial", size: Metric.labelFontSize)
        label.numberOfLines = 0
        label.textAlignment = .center
        label.text = "Famous Quote Must Be Here"
        label.textColor = .systemGray5
        return label
    }()
    
    private lazy var showButton: UIButton = {
        let button = UIButton()
        button.translatesAutoresizingMaskIntoConstraints = false
        button.setTitle("Show Famous Quote", for: .normal)
        button.backgroundColor = .systemBlue
        button.setTitleColor(.white, for: .normal)
        button.titleLabel?.font = UIFont(name: "Arial", size: Metric.buttonFontSize)
        button.layer.cornerRadius = 7
        button.clipsToBounds = true
        button.addTarget(self, action: #selector(buttonTapped), for: .touchUpInside)
        return button
    }()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .white
        title = "Quotes"
        setupHierarchy()
        setupLayout()
    }
    
    private func setupLayout() {
        messageLabel.centerXAnchor.constraint(equalTo: view.centerXAnchor).isActive = true
        messageLabel.centerYAnchor.constraint(equalTo: view.centerYAnchor).isActive = true
        messageLabel.widthAnchor.constraint(equalTo: view.widthAnchor, multiplier: 0.7).isActive = true
        showButton.topAnchor.constraint(equalTo: messageLabel.bottomAnchor, constant: 20).isActive = true
        showButton.widthAnchor.constraint(equalToConstant: view.frame.width / 1.3).isActive = true
        showButton.heightAnchor.constraint(equalToConstant: Metric.buttonHeight).isActive = true
        showButton.centerXAnchor.constraint(equalTo: view.centerXAnchor).isActive = true
    }
    
    private func setupHierarchy() {
        view.addSubview(messageLabel)
        view.addSubview(showButton)
    }
    
    @objc func buttonTapped() {
        coordinator?.eventOccured(with: .showButtonTapped)
    }
}

extension MessageViewController: ViewModelDelegate {
    func enteredCorrectPassCode(message: String){
        coordinator?.eventOccured(with: .dismissPassCode)
        messageLabel.textColor = .systemBlue
        messageLabel.text = "\"\(message)\""
        showButton.setTitle("Show Another Quote", for: .normal)
    }
}
